# honeywell-hsc
Arduino library for Honeywell HSC-series pressure sensors
